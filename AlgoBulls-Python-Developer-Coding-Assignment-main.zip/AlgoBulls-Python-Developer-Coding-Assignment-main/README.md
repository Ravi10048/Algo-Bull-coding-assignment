# AlgoBulls-Python-Developer-Coding-Assignment
coded a simple trading strategy in a Jupyter Notebook

just download the assigment1 code and install all required libraries then simply run it
